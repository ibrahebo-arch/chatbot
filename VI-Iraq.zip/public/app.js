/* VI Iraq – front end */
(() => {
  const $ = (id) => document.getElementById(id);

  // ---------- state ----------
  const state = {
    messages: [],
    quality: 1080,
    seconds: 15,
    language: "العربية",
    characters: "1",
    rates: { 1080: 80 / 60, 720: 44 / 60, 480: 22 / 60 },
    ai: false,
    sending: false,
  };
  const price = (q = state.quality, s = state.seconds) =>
    Math.ceil((state.rates[q] || state.rates[1080]) * s);

  // ---------- clock ----------
  const tick = () => {
    const d = new Date();
    $("clock").textContent = `${d.getHours()}:${String(d.getMinutes()).padStart(2, "0")}`;
  };
  tick();
  setInterval(tick, 15000);
  $("year").textContent = new Date().getFullYear();

  // ---------- background videos ----------
  async function initBackground() {
    try {
      const r = await fetch("/api/videos");
      const { videos } = await r.json();
      if (!videos.length) return;
      const players = [$("bgA"), $("bgB")];
      let idx = 0;
      let active = 0;
      const play = (el, src) => {
        el.src = src;
        el.load();
        el.play().catch(() => {});
      };
      play(players[0], videos[0]);
      players[0].classList.add("show");
      if (videos.length === 1) {
        players[0].loop = true;
        return;
      }
      players[0].loop = false;
      const next = () => {
        idx = (idx + 1) % videos.length;
        const incoming = players[1 - active];
        play(incoming, videos[idx]);
        incoming.classList.add("show");
        players[active].classList.remove("show");
        active = 1 - active;
      };
      players.forEach((p) => p.addEventListener("ended", next));
    } catch {
      /* keep animated gradient fallback */
    }
  }

  // ---------- chat ----------
  const list = $("messages");
  function addMsg(role, content) {
    const el = document.createElement("div");
    el.className = `msg ${role === "user" ? "user" : "bot"}`;
    el.textContent = content;
    list.appendChild(el);
    list.scrollTop = list.scrollHeight;
    return el;
  }
  function typing() {
    const el = document.createElement("div");
    el.className = "msg bot typing";
    el.innerHTML = "<span></span><span></span><span></span>";
    list.appendChild(el);
    list.scrollTop = list.scrollHeight;
    return el;
  }
  const orderPayload = () => ({
    quality: state.quality,
    seconds: state.seconds,
    language: state.language,
    characters: state.characters,
    contact: $("contact").value.trim(),
    description: state.messages.filter((m) => m.role === "user").map((m) => m.content).join("\n"),
  });

  $("composer").addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = $("input").value.trim();
    if (!text || state.sending) return;
    $("input").value = "";
    state.messages.push({ role: "user", content: text });
    addMsg("user", text);
    const t = typing();
    state.sending = true;
    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: state.messages, order: orderPayload() }),
      });
      const data = await r.json();
      t.remove();
      addMsg("bot", data.reply || "…");
      if (data.reply) state.messages.push({ role: "assistant", content: data.reply });
    } catch {
      t.remove();
      addMsg("bot", "تعذّر الاتصال بالخادم، حاول مرة ثانية.");
    } finally {
      state.sending = false;
    }
  });

  // ---------- segments ----------
  function segment(id, key, onChange) {
    const wrap = $(id);
    wrap.addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      wrap.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
      state[key] = isNaN(b.dataset.v) ? b.dataset.v : Number(b.dataset.v);
      onChange && onChange();
    });
  }
  segment("characters", "characters");
  segment("quality", "quality", renderPrice);
  $("language").addEventListener("change", (e) => (state.language = e.target.value));

  // ---------- price slider ----------
  const slider = $("seconds");
  function renderPrice() {
    const p = price();
    $("secVal").textContent = state.seconds;
    $("priceVal").textContent = p;
    $("ctaPrice").textContent = p;
    const amt = document.querySelector(".amount");
    amt.classList.add("bump");
    setTimeout(() => amt.classList.remove("bump"), 150);
    const pct = ((state.seconds - slider.min) / (slider.max - slider.min)) * 100;
    slider.style.setProperty("--fill", `${pct}%`);
    document.querySelectorAll("#quick button").forEach((b) =>
      b.classList.toggle("on", Number(b.dataset.s) === state.seconds)
    );
    renderTable();
  }
  function renderTable() {
    const rows = [
      [15, "15 ثانية"],
      [30, "30 ثانية"],
      [60, "دقيقة"],
    ];
    $("priceTable").innerHTML = rows
      .map(
        ([s, label]) =>
          `<tr><td>${label}</td>` +
          [480, 720, 1080]
            .map((q) => `<td class="${q === state.quality ? "hi" : ""}">$${price(q, s)}</td>`)
            .join("") +
          "</tr>"
      )
      .join("");
  }
  slider.addEventListener("input", () => {
    state.seconds = Number(slider.value);
    renderPrice();
  });
  $("quick").addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    state.seconds = Number(b.dataset.s);
    slider.value = state.seconds;
    renderPrice();
  });

  // ---------- send order ----------
  const toast = (msg) => {
    const t = $("toast");
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => (t.hidden = true), 3500);
  };
  $("sendOrder").addEventListener("click", async () => {
    const note = $("orderNote");
    if (!state.messages.some((m) => m.role === "user")) {
      note.className = "note err";
      note.textContent = "اكتب أولاً في الدردشة وصف الفيديو الذي تريده 👆";
      $("input").focus();
      return;
    }
    const btn = $("sendOrder");
    btn.disabled = true;
    note.className = "note";
    note.textContent = "جارٍ الإرسال…";
    try {
      const r = await fetch("/api/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: state.messages, order: orderPayload() }),
      });
      const data = await r.json();
      note.className = `note ${data.ok ? "ok" : "err"}`;
      note.textContent = data.message;
      toast(data.ok ? "✅ تم استلام طلبك" : "⚠️ حدثت مشكلة");
      if (data.ok) addMsg("bot", `✅ تم إرسال طلبك (${state.quality}p / ${state.seconds} ثانية / $${price()}). سنتواصل معك قريباً!`);
    } catch {
      note.className = "note err";
      note.textContent = "تعذّر الاتصال بالخادم.";
    } finally {
      btn.disabled = false;
    }
  });

  // ---------- help sheet ----------
  $("helpBtn").addEventListener("click", () => ($("helpSheet").hidden = false));
  $("closeHelp").addEventListener("click", () => ($("helpSheet").hidden = true));
  $("helpSheet").addEventListener("click", (e) => {
    if (e.target === $("helpSheet")) $("helpSheet").hidden = true;
  });

  // ---------- boot ----------
  (async () => {
    try {
      const cfg = await (await fetch("/api/config")).json();
      state.ai = cfg.ai;
      if (cfg.rates) state.rates = cfg.rates;
      const s = $("aiState");
      s.textContent = cfg.ai ? "متصل" : "وضع يدوي";
      s.classList.toggle("off", !cfg.ai);
    } catch {}
    renderPrice();
    initBackground();
    addMsg(
      "bot",
      "هلا بيك في VI Iraq 👋\nاكتب لي فكرة الفيديو الذي تريده (المكان، الأجواء، الشخصيات، الرسالة)، واختر اللغة والجودة والمدة من الأسفل، وراح أساعدك تجهّز طلبك."
    );
    state.messages.push({ role: "assistant", content: "هلا بيك في VI Iraq 👋 اكتب لي فكرة الفيديو الذي تريده." });
  })();
})();
